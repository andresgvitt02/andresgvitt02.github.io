// Classe para gerenciar uma coleção de ItemBiblioteca \\
public class Biblioteca
{
    // Coleção de itens \\
    private List<ItemBiblioteca> itens;

    // Construtor \\
    public Biblioteca()
    {
        itens = new List<ItemBiblioteca>();
    }

    // Método para adicionar um item na biblioteca \\
    public void AdicionarItem(ItemBiblioteca item)
    {
        itens.Add(item);
        Console.WriteLine($"{item.Titulo} foi adicionado na biblioteca.");
    }

    // Método para remover um item da biblioteca \\
    public void RemoverItem(ItemBiblioteca item)
    {
        itens.Remove(item);
        Console.WriteLine($"{item.Titulo} foi removido da biblioteca.");
    }

    // Método para remover um item da biblioteca com base no título \\
    public ItemBiblioteca BuscarItemPorTitulo(string titulo)
    {
        ItemBiblioteca itemEncontrado = itens.Find(item => item.Titulo == titulo);

        if (itemEncontrado != null)
        {
            Console.WriteLine($"Livro encontrado por título: {itemEncontrado.Titulo}");
        }
        else
        {
            Console.WriteLine("Livro não encontrado por título.");
        }

        return itemEncontrado;
    }
    // Método para remover um item da biblioteca com base no Id \\
    public ItemBiblioteca BuscarItemPorId(int id)
    {
        ItemBiblioteca itemEncontrado = itens.Find(item => item.Id == id);

        if (itemEncontrado != null)
        {
            Console.WriteLine($"Livro encontrado por ID: {itemEncontrado.Titulo}");
        }
        else
        {
            Console.WriteLine("Livro não encontrado por ID.");
        }

        return itemEncontrado;
    }
}
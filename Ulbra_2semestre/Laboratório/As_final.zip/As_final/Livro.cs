// Classe derivada de ItemBiblioteca \\
public class Livro : ItemBiblioteca
{
    // Propriedade adicional \\
    public string Autor { get; set; }

    // Construtor \\
    public Livro(int id, string titulo, string autor) : base(id, titulo)
    {
        Autor = autor;
        InicializarDescricaoInterna();
    }

    // Método para inicializar a DescricaoInterna
    private void InicializarDescricaoInterna()
    {
        DescricaoInterna = $"Livro escrito por {Autor}";
    }

    // Método para exibir a Descrição interna \\
    public void ExibirDescricaoInterna()
    {
        Console.WriteLine($"Descrição Interna: {DescricaoInterna}");
    }
}